# Flutter-application  📱 -
- It is a flutter application built for all compatible devices android, web, macOS, and ios.
- These applications are made so users can control the IOT devices from anywhere without regional restrictions.
# 📱 Technologies / Tools used for building this app include: 
- Android Studio / VS code 
- Flutter/Dart
- Firebase
- Esp32
- Arduino IDE
## ✨Features

- User Login & Sign up
- User Databases
- User Authentication
- Choices for application to do operation
- Control the IOT devices
 ## Screenshots 📱
 ![Screenshot (19)](https://github.com/Gauravshukl/Flutter-Firebase-Series-main/assets/48097137/4d598d5d-d0c7-4606-a06a-ad7397b75556)
 ![Screenshot (19)](https://github.com/Gauravshukl/Flutter-Firebase-Series-main/assets/48097137/b7a6f3dc-dfb3-42d8-b4ab-2e74cffdab1d)
 ![Screenshot (19)](https://github.com/Gauravshukl/Flutter-Firebase-Series-main/assets/48097137/41420f96-25ae-4ecc-865c-827614ca2a3c)
 ![Screenshot (19)](https://github.com/Gauravshukl/Flutter-Firebase-Series-main/assets/48097137/aad938d9-59f4-4d34-ba96-06b7776f3c18)
 ![Screenshot (19)](https://github.com/Gauravshukl/Flutter-Firebase-Series-main/assets/48097137/393b32ac-2ea0-4108-833e-996ac439e699)
 ![Screenshot (19)](https://github.com/Gauravshukl/Flutter-Firebase-Series-main/assets/48097137/c7788bcd-498e-43e5-a38a-714dc5f361da)
 ![Screenshot (19)](https://github.com/Gauravshukl/Flutter-Firebase-Series-main/assets/48097137/deadf02c-4b05-42c4-90b3-8a6fb24d2858)
 ![Screenshot (19)](https://github.com/Gauravshukl/Flutter-Firebase-Series-main/assets/48097137/a8317d8a-d346-433c-bcea-a9b751422bc3)
 ![Screenshot (19)](https://github.com/Gauravshukl/Flutter-Firebase-Series-main/assets/48097137/8963dd24-36c6-4b5d-baec-7007a604838f)
 ![Screenshot (99)](https://github.com/Gauravshukl/Flutter-Firebase-Series-main/assets/48097137/380481af-0e43-49ce-8d43-191dd57de2c6)
 ![Screenshot (29)](https://github.com/Gauravshukl/Flutter-Firebase-Series-main/assets/48097137/bb548be8-9263-4de7-ba73-898edfd3f12c)
 ![Screenshot (46)](https://github.com/Gauravshukl/Flutter-Firebase-Series-main/assets/48097137/7a669660-5509-43e6-bcc9-21fbf246e66a)
 ![Screenshot (49)](https://github.com/Gauravshukl/Flutter-Firebase-Series-main/assets/48097137/70069509-d731-42fb-8d6e-9b7744eff7bc)
 ![Screenshot (66)](https://github.com/Gauravshukl/Flutter-Firebase-Series-main/assets/48097137/944e0bc9-e386-443c-9f07-740abd32a17b)
![Screenshot (67)](https://github.com/Gauravshukl/Flutter-Firebase-Series-main/assets/48097137/802a4ac1-eb21-4e09-ac68-e63e6ba129f7)

